#ifndef DELAY_H
#define DELAY_H

#include <stdint.h>

void TimConfig(void);
void Delay_us(uint16_t us);
void Delay_ms(uint16_t ms);


#endif
